import tweepy
import webbrowser
import time
consumer_key = "Yr2w21j6wiZULiuAQAc6BsDJk"
consumer_secret = "eR3J2aYWn8vzvA3huuwZH17L97OKEHQYmWcxLWctPyHJAZUMV5"

callback_uri = 'oob' 

auth = tweepy.OAuthHandler(consumer_key, consumer_secret, callback_uri)
redirect_url = auth.get_authorization_url()

webbrowser.open(redirect_url)

user_pint_input = input("What's the pin value? ")

auth.get_access_token(user_pint_input)

api = tweepy.API(auth)

# me = api.me()

# print(me.screen_name, me.id)

user_list = ["CNN", "FoxNews", "globalnewstdwado" ]

for twitter_name in user_list: 
    #try-catch exception to catch errors. 
    try:    
        tweets = api.user_timeline(screen_name=twitter_name,
        count=10
        )

        for info in tweets[:2]:
            print("ID: {}".format(info.id))
            print(info.created_at)
            print(info.text)
            print("\n")
    except:
        print("failed to get user timeline, exception thrown")



#stream listener

class MyStreamListener(tweepy.StreamListener):
    def on_status(self, status):
        print(status)

        

MyStreamListener = MyStreamListener()
myStream = tweepy.Stream(auth = api.auth, listener=MyStreamListener)

# myStream.filter(follow=[str(me.id)])

while True: 
    pass